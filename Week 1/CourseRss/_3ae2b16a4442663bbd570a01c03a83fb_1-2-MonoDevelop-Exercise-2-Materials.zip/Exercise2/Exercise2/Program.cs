﻿using System;

namespace Exercise2
{
    /// <summary>
    /// Exercise 2 solution
    /// </summary>
    class MainClass
    {
        /// <summary>
        /// Uses ordered generic dynamic array
        /// </summary>
        /// <param name="args">command-line arguments</param>
        public static void Main(string[] args)
        {
            Console.WriteLine();
        }
    }
}
