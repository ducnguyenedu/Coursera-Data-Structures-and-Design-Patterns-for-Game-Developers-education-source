﻿using System;

namespace ImplementingAnInterface
{
    /// <summary>
    /// Implementing an Interface lecture code
    /// </summary>
    class MainClass
    {
        /// <summary>
        /// Demonstrates implementing an interface
        /// </summary>
        /// <param name="args">The command-line arguments.</param>
        public static void Main(string[] args)
        {
            // create array of rectangles

            // add rectangles to array

            // print rectangles in array

            Console.WriteLine();
        }
    }
}
