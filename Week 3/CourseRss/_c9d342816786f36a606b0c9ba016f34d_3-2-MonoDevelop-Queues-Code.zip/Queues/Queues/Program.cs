﻿using System;

namespace Queues
{
    /// <remarks>
    /// Runs the test cases for the Queue and PriorityQueue classes
    /// </remarks>
    class MainClass
    {
        /// <summary>
        /// Run test cases
        /// </summary>
        /// <param name="args">command-line arguments</param>
        public static void Main(string[] args)
        {
            TestQueue.RunTestCases();
            TestPriorityQueue.RunTestCases();
        }
    }
}
