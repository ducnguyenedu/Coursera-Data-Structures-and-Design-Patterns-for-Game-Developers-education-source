﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TreeTraversal
{
    /// <summary>
    /// An enumeration of the child sides
    /// </summary>
    enum ChildSide
    {
        Left,
        Right
    }
}
