﻿using System;

namespace GraphSearching
{
    public enum SearchType
    {
        BreadthFirst,
        DepthFirst
    }
}
