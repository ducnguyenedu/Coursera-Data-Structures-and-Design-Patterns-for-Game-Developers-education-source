﻿using System;

namespace ImplementingAnInterface
{
    /// <summary>
    /// Implementing an Interface lecture code
    /// </summary>
    class MainClass
    {
        /// <summary>
        /// Demonstrates implementing an interface
        /// </summary>
        /// <param name="args">The command-line arguments.</param>
        public static void Main(string[] args)
        {
            // create array of rectangles
            OrderedDynamicArray<Rectangle> rectangles = 
                new OrderedDynamicArray<Rectangle>();

            // add rectangles to array
            rectangles.Add(new Rectangle(3, 4));
            rectangles.Add(new Rectangle(2, 2));
            rectangles.Add(new Rectangle(1, 2));

            // print rectangles in array
            Console.WriteLine(rectangles.ToString());

            Console.WriteLine();
        }
    }
}
