﻿using System;

namespace Exercise1
{
    /// <summary>
    /// Exercise 1 solution
    /// </summary>
    class MainClass
    {
        /// <summary>
        /// Tests LastIndexOf and AllIndexesOf methods
        /// </summary>
        /// <param name="args">command-line arguments</param>
        public static void Main(string[] args)
        {
            // build test dynamic array

            // test LastIndexOf with one item in dynamic array

            // test LastIndexOf with multiple items in dynamic array

            // test LastIndexOf with item not in dynamic array

            // test AllIndexesOf with one item in dynamic array

            // test AllIndexesOf with multiple items in dynamic array

            // test AllIndexesOf with item not in dynamic array

            Console.WriteLine();
        }
    }
}
