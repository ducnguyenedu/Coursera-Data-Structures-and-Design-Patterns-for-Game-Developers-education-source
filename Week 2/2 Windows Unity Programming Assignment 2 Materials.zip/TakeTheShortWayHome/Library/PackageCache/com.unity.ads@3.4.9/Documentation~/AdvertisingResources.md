# Advertiser resources
Learn about creative asset specs, campaign performance reporting, and more. 

* [Creative asset specs](AdvertisingResourcesCreativeSpecs.md)
* [Statistics API](AdvertisingResourcesStats.md)
* [FAQs](AdvertisingResourcesFaq.md)