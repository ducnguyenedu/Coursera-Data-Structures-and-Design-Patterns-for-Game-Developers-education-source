﻿using System;

namespace TreeTraversal
{
    /// <summary>
    /// An enumeration of the child sides
    /// </summary>
    public enum ChildSide
    {
        Left,
        Right
    }
}

