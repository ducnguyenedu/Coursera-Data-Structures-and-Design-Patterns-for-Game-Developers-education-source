﻿using System;

namespace Graphs
{
    /// <summary>
    /// Tests Graph and GraphNode classes
    /// </summary>
    class MainClass
    {
        /// <summary>
        /// Tests classes
        /// </summary>
        /// <param name="args">command-line arguments</param>
        public static void Main(string[] args)
        {
            TestGraphNode.RunTestCases();
            TestGraph.RunTestCases();
            Console.WriteLine();
        }
    }
}
