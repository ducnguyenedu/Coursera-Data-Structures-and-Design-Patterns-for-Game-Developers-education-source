﻿using System;

namespace Trees
{
    /// <summary>
    /// Tests the Tree and TreeNode classes
    /// </summary>
    class MainClass
    {
        /// <summary>
        /// Tests classes
        /// </summary>
        /// <param name="args">command-line arguments</param>
        public static void Main(string[] args)
        {
            TestTreeNode.RunTestCases();
            TestTree.RunTestCases();
            Console.WriteLine();
        }
    }
}
