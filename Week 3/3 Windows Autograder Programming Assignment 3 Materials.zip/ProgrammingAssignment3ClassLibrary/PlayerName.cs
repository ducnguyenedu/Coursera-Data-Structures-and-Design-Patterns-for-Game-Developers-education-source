﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// An enumeration of the player names
/// </summary>
public enum PlayerName
{
    Player1,
    Player2
}
