﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// An enumeration of the bullet directions
/// </summary>
public enum BulletDirection
{
    Left,
    Right
}
