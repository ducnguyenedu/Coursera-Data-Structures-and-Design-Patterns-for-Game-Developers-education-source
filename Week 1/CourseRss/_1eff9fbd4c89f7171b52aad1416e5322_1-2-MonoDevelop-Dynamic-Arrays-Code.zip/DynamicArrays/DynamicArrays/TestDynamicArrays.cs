﻿using System;

namespace DynamicArrays
{
    /// <remarks>
    /// Runs the test cases for all the dynamic array classes
    /// </remarks>
    public class TestDynamicArrays
    {
        /// <summary>
        /// Tests the classes
        /// </summary>
        /// <param name="args">command-line arguments</param>
        public static void Main(string[] args)
        {
            // test cases for integer dynamic arrays
            TestUnorderedIntDynamicArray.RunTestCases();
            TestOrderedIntDynamicArray.RunTestCases();

            // test cases for generic dynamic arrays
            TestUnorderedDynamicArray.RunTestCases();
            TestOrderedDynamicArray.RunTestCases();
        }
    }
}
