﻿using System;

namespace Dictionaries
{
    /// <summary>
    /// Dictionaries lecture code
    /// </summary>
    class MainClass
    {
        /// <summary>
        /// Demonstrates using a dictionary
        /// </summary>
        /// <param name="args">command-line arguments</param>
        public static void Main(string[] args)
        {
            // create dictionary of high scores by gamertag

            // prompt for and get gamertag from user

            // print high score or error message for gamertag

            Console.WriteLine();
        }
    }
}
