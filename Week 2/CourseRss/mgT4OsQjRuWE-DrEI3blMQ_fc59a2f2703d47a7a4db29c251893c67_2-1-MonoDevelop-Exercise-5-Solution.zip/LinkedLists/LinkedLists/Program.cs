﻿using System;

namespace LinkedLists
{
    /// <summary>
    /// Tests the linked lists
    /// </summary>
    class MainClass
    {
        /// <summary>
        /// Tests the linked lists
        /// </summary>
        /// <param name="args">command-line arguments</param>
        public static void Main(string[] args)
        {
            TestUnsortedLinkedList.RunTestCases();
            TestSortedLinkedList.RunTestCases();

            Console.WriteLine();
        }
    }
}
